local dados = AHForeverDados
if not dados then return end

local function moeda(cobre)
  if GetCoinTextureString then return GetCoinTextureString(cobre) end
  return string.format("%dg %ds %dc", cobre / 10000, cobre / 100 % 100, cobre % 100)
end

local function escrever(tooltip, link)
  local id = link and tonumber(link:match("item:(%d+)"))
  local p = id and dados.precos[id]
  if not p then return end
  tooltip:AddLine(" ")
  tooltip:AddDoubleLine("Leilão: menor preço", moeda(p[1]), 1, .82, 0, 1, 1, 1)
  if p[2] > 0 then tooltip:AddDoubleLine("Leilão: mercado", moeda(p[2]), 1, .82, 0, 1, 1, 1) end
  tooltip:AddDoubleLine("À venda", p[3], 1, .82, 0, 1, 1, 1)
  if p[4] then tooltip:AddDoubleLine("Vendas por dia", p[4], 1, .82, 0, 1, 1, 1) end
  tooltip:AddLine(dados.casa .. ", " .. dados.quando, .6, .6, .6)
  tooltip:Show()
end

if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip)
    if tooltip.GetItem then
      local _, link = tooltip:GetItem()
      escrever(tooltip, link)
    end
  end)
else
  for _, tooltip in ipairs({GameTooltip, ItemRefTooltip}) do
    tooltip:HookScript("OnTooltipSetItem", function(self)
      local _, link = self:GetItem()
      escrever(self, link)
    end)
  end
end

SLASH_AHFOREVER1 = "/ahf"
SlashCmdList["AHFOREVER"] = function()
  print("Goblinomics: preços de " .. dados.casa .. ", coletados em " .. dados.quando .. ".")
end
